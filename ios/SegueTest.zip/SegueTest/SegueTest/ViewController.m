//
//  ViewController.m
//  SegueTest
//
//  Created by Jake Jarvis on 7/3/12.
//  Copyright (c) 2012 Jake Jarvis. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController



// this adds actions to the segue that are performed right before the transition

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
	ViewController *next = (ViewController *)segue.destinationViewController;  // access the next view with a variable called next
	next -> angle = self -> angle; // change the angle variable of the next view to the angle from this view
}


- (IBAction)updateAngle:(UISlider*)sender {
	angleLabel.text = [NSString stringWithFormat:@"%.2f", sender.value];    // update the label
	
	angle = sender.value;            // set the double variable called angle to the slider value
}

- (IBAction)pressBack:(id)sender {
	[self dismissViewControllerAnimated:YES completion:nil];    // instead of creating a new instance of the previous view when the user presses back, just dismiss the current view instead
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	
	
	
	angleTextField.text = [NSString stringWithFormat:@"%f", angle];   // as soon as the next view loads, update the text box with the number from the slider

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
