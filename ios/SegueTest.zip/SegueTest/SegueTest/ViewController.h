//
//  ViewController.h
//  SegueTest
//
//  Created by Jake Jarvis on 7/3/12.
//  Copyright (c) 2012 Jake Jarvis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
	double angle;
	IBOutlet UILabel *angleLabel;
	IBOutlet UITextField *angleTextField;
}

- (IBAction)updateAngle:(UISlider*)sender;

- (IBAction)pressBack:(id)sender;

@end
