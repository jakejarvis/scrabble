//
//  ViewController.h
//  Beautiful
//
//  Created by Jake Jarvis on 6/18/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)thanksClicked:(id)sender;

@end
