//
//  ViewController.m
//  Random
//
//  Created by Jake Jarvis on 6/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)pressGenerate:(id)sender {
    myNumber = (arc4random() % 100 - 1 + 1) + 1;  // Generates a random number from 1 to 100
                                                  //          (including 1 and 100).

                                                  // The formula is ... (arc4random() % (high - low + 1)) + low
                                                  // So if you wanted random numbers between 18 and 53, you
                                                  // would do:     number = (arc4random() % (53 - 18 + 1)) + 18

                                                  // ...Easy, right? :) We'll talk about this more today.


    // We told the phone to expect us to change the "myLabel" label on our view controller.
    // Now we're doing it!

    myLabel.text = [NSString stringWithFormat:@"%i", myNumber];

    // IMPORTANT NOTE: We can't just set myLabel.text equal to myNumber, our integer, because
    // labels always need a STRING for their text!
    // The second half of that line converts myNumber into a string that myLabel can understand.
}

@end
