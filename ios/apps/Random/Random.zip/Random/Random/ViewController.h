//
//  ViewController.h
//  Random
//
//  Created by Jake Jarvis on 6/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    int myNumber;                 // Tell our phone to expect us to set the "myNumber"
                                  // variable equal to some integer.
                                  // Math class refresher... ints = FULL numbers
                                  //                                (NO DECIMALS!)

    IBOutlet UILabel *myLabel;    // Tell our phone to expect us to control the
                                  // LABEL on our ViewController.xib which will
                                  // display our random number variable!
}

- (IBAction)pressGenerate:(id)sender;     // Tell our phone to expect a method that we'll
                                          // link to our button's "touch up inside" event.
                                          // This should look pretty familiar!

@end
