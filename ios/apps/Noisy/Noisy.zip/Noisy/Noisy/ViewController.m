//
//  ViewController.m
//  Noisy
//
//  Created by Jake Jarvis on 6/18/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction) playClicked:(id)sender {
	// Open a music file that's been dragged into the project, called lady.mp3
	NSString * mp3Path = [NSString stringWithFormat:@"%@/lady.mp3", [[NSBundle mainBundle] resourcePath]];
	NSURL *url = [NSURL fileURLWithPath:mp3Path];
    
	// create an AudioPlayer with the file used above
	NSError *error;
	audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
	if (audioPlayer == nil)
		NSLog(@"Error playing sound %@", [error description]);
	else
		[audioPlayer play];
}

- (IBAction)stopClicked:(id)sender {
	[audioPlayer stop];
}

@end
