//
//  ViewController.h
//  Noisy
//
//  Created by Jake Jarvis on 6/18/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface ViewController : UIViewController {
    // We keep track of the audio player here on the class
    AVAudioPlayer *audioPlayer;
}

// Our UIButton clicked methods
- (IBAction)playClicked:(id)sender;
- (IBAction)stopClicked:(id)sender;

@end
