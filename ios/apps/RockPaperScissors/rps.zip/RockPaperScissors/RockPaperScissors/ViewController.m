//
//  ViewController.m
//  RockPaperScissors

//
//  Created by Jake Jarvis on 6/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}


- (IBAction)pressRock:(id)sender {
    
    // user chose rock, let's see what the computer chooses...
    
    compChoice = (arc4random() % 3); // generates number from 0 to 2, including 0 and 2 (in other words: 0, 1, or 2)
    
    labelYou.text = @"Rock";
    imageYou.image = [UIImage imageNamed:@"hand-rock.png"];
    
    if(compChoice == 0) {
        labelComp.text = @"Rock";
        imageComp.image = [UIImage imageNamed:@"hand-rock.png"];
        labelWinner.text = @"It's a tie!";
    } else if(compChoice == 1) {
        labelComp.text = @"Paper";
        imageComp.image = [UIImage imageNamed:@"hand-paper.png"];
        labelWinner.text = @"Computer wins!";
    } else if(compChoice == 2) {
        labelComp.text = @"Scissors";
        imageComp.image = [UIImage imageNamed:@"hand-scissors.png"];
        labelWinner.text = @"You win!!!";
    } else {
        NSLog(@"Oops, something went terribly wrong with the computer's choice!");
    }
    
}

- (IBAction)pressPaper:(id)sender {

    // user chose paper, let's see what the computer chooses...
    
    compChoice = (arc4random() % 3); // generates number from 0 to 2, including 0 and 2 (in other words: 0, 1, or 2)
    
    labelYou.text = @"Paper";
    imageYou.image = [UIImage imageNamed:@"hand-paper.png"];
    
    if(compChoice == 0) {
        labelComp.text = @"Rock";
        imageComp.image = [UIImage imageNamed:@"hand-rock.png"];
        labelWinner.text = @"You win!!!";
    } else if(compChoice == 1) {
        labelComp.text = @"Paper";
        imageComp.image = [UIImage imageNamed:@"hand-paper.png"];
        labelWinner.text = @"It's a tie!";
    } else if(compChoice == 2) {
        labelComp.text = @"Scissors";
        imageComp.image = [UIImage imageNamed:@"hand-scissors.png"];
        labelWinner.text = @"Computer wins!";
    } else {
        NSLog(@"Oops, something went terribly wrong with the computer's choice!");
    }

}

- (IBAction)pressScissors:(id)sender {

    // user chose scissors, let's see what the computer chooses...
    
    compChoice = (arc4random() % 3); // generates number from 0 to 2, including 0 and 2 (in other words: 0, 1, or 2)
    
    labelYou.text = @"Scissors";
    imageYou.image = [UIImage imageNamed:@"hand-scissors.png"];
    
    if(compChoice == 0) {
        labelComp.text = @"Rock";
        imageComp.image = [UIImage imageNamed:@"hand-rock.png"];
        labelWinner.text = @"Computer wins!";
    } else if(compChoice == 1) {
        labelComp.text = @"Paper";
        imageComp.image = [UIImage imageNamed:@"hand-paper.png"];
        labelWinner.text = @"You win!!!";
    } else if(compChoice == 2) {
        labelComp.text = @"Scissors";
        imageComp.image = [UIImage imageNamed:@"hand-scissors.png"];
        labelWinner.text = @"It's a tie!";
    } else {
        NSLog(@"Oops, something went terribly wrong with the computer's choice!");
    }

}


@end
