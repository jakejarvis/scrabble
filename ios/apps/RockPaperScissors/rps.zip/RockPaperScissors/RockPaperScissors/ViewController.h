//
//  ViewController.h
//  RockPaperScissors
//
//  Created by Jake Jarvis on 6/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    
    int compChoice; // 0 = Rock, 1 = Paper, 2 = Scissors
    
    IBOutlet UIImageView *imageYou;
    IBOutlet UIImageView *imageComp;
    
    IBOutlet UILabel *labelYou;
    IBOutlet UILabel *labelComp;
    
    IBOutlet UILabel *labelWinner;
    
}

- (IBAction)pressRock:(id)sender;
- (IBAction)pressPaper:(id)sender;
- (IBAction)pressScissors:(id)sender;

@end
