//
//  ViewController.h
//  ButtonTest
//
//  Created by Jake Jarvis on 7/4/12.
//  Copyright (c) 2012 Jake Jarvis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)pressButton:(id)sender;

@end
