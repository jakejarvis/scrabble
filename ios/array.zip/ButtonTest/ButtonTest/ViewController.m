//
//  ViewController.m
//  ButtonTest
//
//  Created by Jake Jarvis on 7/4/12.
//  Copyright (c) 2012 Jake Jarvis. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController


- (IBAction)pressButton:(id)sender {
	
	//NSLog(@"button pressed");
	
	
	UIButton *button = sender;
	
	if(button.tag == 1) {
		NSLog(@"first button pressed");
	}
	else if(button.tag == 2) {
		NSLog(@"second button pressed");
	}
	else if(button.tag == 3) {
		NSLog(@"third button pressed");
	}
	
	
	
	button.backgroundColor = [UIColor redColor];
	
	[points replaceObjectAtIndex:button.tag withObject:[NSNumber numberWithInt:1]];
	
	
	
	
	UIButton *neighbor =  [self.view viewWithTag:button.tag-1];
	neighbor.backgroundColor = [UIColor redColor];
	
	[points replaceObjectAtIndex:button.tag withObject:[NSNumber numberWithInt:1]];
	
	
	
	
	neighbor =  [self.view viewWithTag:button.tag+1];
	neighbor.backgroundColor = [UIColor redColor];
	
	[points replaceObjectAtIndex:button.tag withObject:[NSNumber numberWithInt:1]];
	
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	
	
	
	points = [[NSMutableArray alloc] init];
	
	
	for(int i = 0; i < 100; i++) {
		[points addObject:[NSNumber numberWithInt:0]];
	}
	
	
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
