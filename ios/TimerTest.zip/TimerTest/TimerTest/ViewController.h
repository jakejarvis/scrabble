//
//  ViewController.h
//  TimerTest
//
//  Created by Jake Jarvis on 7/3/12.
//  Copyright (c) 2012 Jake Jarvis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
	int seconds;
	IBOutlet UILabel *myLabel;
	
	IBOutlet UIImageView *smurf;
	
	NSTimer *myTimer;
}

- (IBAction)pressStart:(id)sender;
- (void)updateTimer;

@end
