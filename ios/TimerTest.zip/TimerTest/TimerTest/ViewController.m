//
//  ViewController.m
//  TimerTest
//
//  Created by Jake Jarvis on 7/3/12.
//  Copyright (c) 2012 Jake Jarvis. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)pressStart:(id)sender {
	
	myTimer = [NSTimer scheduledTimerWithTimeInterval:.05
											   target:self
											 selector:@selector(updateTimer)
											 userInfo:nil
											  repeats:YES];
	
}

- (void)updateTimer {
	
	seconds += 1;
	
	myLabel.text = [NSString stringWithFormat:@"%i", seconds];
	
	
	
	CGRect tempFrame = smurf.frame;
	
	tempFrame.origin.y = tempFrame.origin.y + 4;
	
	[smurf setFrame:tempFrame];
	
	
	
}

@end
