//
//  ViewController.m
//  AccelTest
//
//  Created by Jake Jarvis on 7/5/12.
//  Copyright (c) 2012 Jake Jarvis. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void) accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration {
	
	CGRect planeFrame = plane.frame;
	
	planeFrame.origin.y = planeFrame.origin.y + ((acceleration.z + 0.75) * 20);
	
	[plane setFrame:planeFrame];
	
	
	NSLog([NSString stringWithFormat:@"%@%f", @"Z: ", acceleration.z]);
	
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	
    [[UIAccelerometer sharedAccelerometer] setDelegate:self];
    [[UIAccelerometer sharedAccelerometer] setUpdateInterval:.033];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
