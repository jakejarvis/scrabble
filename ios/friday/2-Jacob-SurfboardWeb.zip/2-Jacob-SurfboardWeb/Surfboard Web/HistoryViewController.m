//
//  HistoryViewController.m
//  Surfboard Web
//
//  Created by iD Student on 7/11/12.
//  Copyright (c) 2012 Microchip Apps. All rights reserved.
//

#import "HistoryViewController.h"
NSMutableArray *history;
NSMutableArray *favorites;
@interface HistoryViewController ()

@end

@implementation HistoryViewController

/*- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
 {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization
 }
 return self;
 }*/

- (void)viewDidLoad
{
    history = [[NSUserDefaults standardUserDefaults] objectForKey:@"history"];
    favorites = [[NSUserDefaults standardUserDefaults] objectForKey:@"favorites"];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Actions

- (IBAction)done:(id)sender
{
    [self.delegate flipsideViewControllerDidFinish:self];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView.tag == 1) {
        NSLog(@"history count");
        return [history count];
    }else {
        NSLog(@"favorites count %i", [favorites count]);
        return [favorites count];
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView.tag == 1) {
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"history item"];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"history item"];
        }
        NSUInteger row = [indexPath row];
        cell.textLabel.text = [history objectAtIndex:row];
        return cell;
    }else {
        NSLog(@"STUFF HAPPENED WILL!");
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"favorites item"];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"favorites item"];
        }
        NSUInteger row = [indexPath row];
        cell.textLabel.text = [favorites objectAtIndex:row];
        return cell;
    }
}
-(IBAction)buttonclearhistory:(id)sender{
    //[history removeAllObjects];
    [[NSUserDefaults standardUserDefaults] setValue:history forKey:@"history"];
    //Refresh table
    NSLog(@"watermelon");
    history = [[NSUserDefaults standardUserDefaults] objectForKey:@"history"];
    [HistoryTable reloadData];
}
-(IBAction)buttonclearfavs:(id)sender {
    [favorites removeAllObjects];
    [[NSUserDefaults standardUserDefaults] setValue:favorites forKey:@"favorites"];
    //Refresh table
    favorites = [[NSUserDefaults standardUserDefaults] objectForKey:@"favorites"];
    [favsTable reloadData];
}
@end
