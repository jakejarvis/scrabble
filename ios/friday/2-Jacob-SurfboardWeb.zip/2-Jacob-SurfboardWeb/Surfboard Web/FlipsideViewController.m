//
//  FlipsideViewController.m
//  Surfboard Web
//
//  Created by iD Student on 7/10/12.
//  Copyright (c) 2012 Microchip Apps. All rights reserved.
//

#import "FlipsideViewController.h"

@interface FlipsideViewController ()

@end

@implementation FlipsideViewController

- (void)viewDidLoad{
    [super viewDidLoad];
    self->thenewhome.delegate = self;
    thenewhome.text = [[NSUserDefaults standardUserDefaults] stringForKey:@"homepage"];
    
    
    
    if(thenewhome.text != nil){
        
    }
    else{
        thenewhome.text = @"apple.com";
    }

}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

#pragma mark - Actions

- (IBAction)done:(id)sender
{
    [self.delegate flipsideViewControllerDidFinish:self];
}
-(IBAction)pagechange:(id)sender{
    switch ([Pagesel selectedSegmentIndex]) {
        case 0:
            pages = 0;
            Pagestep2.value = 0;
            Pagenumber.text = [NSString stringWithFormat:@"%i", pages];
            break;
        case 1:
            pages = 25;
            Pagestep2.value = 25;
            Pagenumber.text = [NSString stringWithFormat:@"%i", pages];
            break;
        case 2:
            pages = 50;
            Pagestep2.value = 50;
            Pagenumber.text = [NSString stringWithFormat:@"%i", pages];
            break;
        case 3:
            pages = 125;
            Pagestep2.value = 125;
            Pagenumber.text = [NSString stringWithFormat:@"%i", pages];
            break;
        case 4:
            pages = 500;
            Pagestep2.value = 500;
            Pagenumber.text = [NSString stringWithFormat:@"%i", pages];
            break;
        case 5:
            pages = 1000;
            Pagestep2.value = 1000;
            Pagenumber.text = [NSString stringWithFormat:@"%i", pages];
            break;
    }
}
-(IBAction)incchange:(id)sender{
    pages = Pagestep2.value;
    Pagenumber.text = [NSString stringWithFormat:@"%i", pages];
}
-(IBAction)custom:(id)sender{
    NSString *Customstr;
    Customstr = Pagecustom2.text;
    double myDouble = [Customstr doubleValue];
    pages = myDouble;
    Pagenumber.text = [NSString stringWithFormat:@"%i", pages];
}
-(IBAction)newhome:(id)sender{
    homepage = thenewhome.text;
    [[NSUserDefaults standardUserDefaults] setValue:homepage forKey:@"homepage"];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Yay!"
                                                    message:@"Homepage set!"
                                                   delegate:self
                                          cancelButtonTitle:nil
                                          otherButtonTitles:@"OK", nil, nil];
    [alert show];
}
-(IBAction)cleartabs:(id)sender{
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"url1"];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"url2"];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"url3"];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"url4"];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"url5"];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"url6"];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"url7"];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"url8"];
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:@"url9"];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Tabs cleared!"
                                                    message:@"Success!"
                                                   delegate:self
                                          cancelButtonTitle:nil
                                          otherButtonTitles:@"OK", nil, nil];
    [alert show];

}
@end
