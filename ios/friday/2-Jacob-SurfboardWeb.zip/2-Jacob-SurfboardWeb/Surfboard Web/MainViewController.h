//
//  MainViewController.h
//  Surfboard Web
//
//  Created by iD Student on 7/10/12.
//  Copyright (c) 2012 Microchip Apps. All rights reserved.
//

#import "FlipsideViewController.h"
#import "HistoryViewController.h"
#import <UIKit/UIKit.h>
@interface MainViewController : UIViewController <FlipsideViewControllerDelegate>{
    IBOutlet UITextField *urlTextField;
    NSMutableArray *history;
    IBOutlet UIWebView *webView;
@public NSString *url1;
    @public NSString *url2;
@public NSString *url3;
@public NSString *url4;
@public NSString *url5;
@public NSString *url6;
@public NSString *url7;
@public NSString *url8;
@public NSString *url9;
    IBOutlet UIWebView *webViewX;
    IBOutlet UIActivityIndicatorView *loading;
@public int currtab;
    IBOutlet UIPinchGestureRecognizer *zoom;
    IBOutlet UIButton *reload;
}
- (IBAction)showInfo:(id)sender;
-(IBAction)pressBack:(id)sender;
-(IBAction)pressFwd:(id)sender;
-(IBAction)pressGo:(id)sender;
- (void) loadURLString: (NSString*)address;
-(IBAction)url1:(id)sender;
-(IBAction)url2:(id)sender;
-(IBAction)url3:(id)sender;
-(IBAction)url4:(id)sender;
-(IBAction)url5:(id)sender;
-(IBAction)url6:(id)sender;
-(IBAction)url7:(id)sender;
-(IBAction)url8:(id)sender;
-(IBAction)url9:(id)sender;
-(IBAction)urlload:(id)sender;
-(IBAction)newfav:(id)sender;
-(IBAction)zoomaction:(id)sender;
@end
