//
//  MainViewController.m
//  Surfboard Web
//
//  Created by iD Student on 7/10/12.
//  Copyright (c) 2012 Microchip Apps. All rights reserved.
//

#import "MainViewController.h"
#import "FlipsideViewController.h"
NSString *currentpage;
int currnum;
NSURL *myUrl;
NSString *nowpage;
NSMutableData *mydata;
NSString *home;
NSMutableArray *favorites;
@interface MainViewController ()

@end

@implementation MainViewController

- (void)viewDidLoad
{
    webView.scalesPageToFit = YES;
    
    home = [[NSUserDefaults standardUserDefaults] stringForKey:@"homepage"];
    url1 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url1"];
    url2 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url2"];
    url3 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url3"];
    url4 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url4"];
    url5 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url5"];
    url6 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url6"];
    url7 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url7"];
    url8 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url8"];
    url9 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url9"];
    if(home != nil){
        
    }
    else{
        home = @"apple.com";
    }
    currtab = 1;
    [super viewDidLoad];
    
	// Do any additional setup after loading the view, typically from a nib.
    history = [[NSMutableArray alloc] init];
    favorites = [[NSMutableArray alloc] init];
    NSLog(@"banana");
    
    [self loadURLString: home];
    
    urlTextField.delegate = self;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    [self loadURLString: urlTextField.text];
    return NO;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

#pragma mark - Flipside View

- (void)flipsideViewControllerDidFinish:(FlipsideViewController *)controller
{
    [self dismissModalViewControllerAnimated:YES];
    url1 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url1"];
    url2 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url2"];
    url3 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url3"];
    url4 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url4"];
    url5 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url5"];
    url6 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url6"];
    url7 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url7"];
    url8 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url8"];
    url9 = [[NSUserDefaults standardUserDefaults] stringForKey:@"url9"];
}

- (IBAction)showInfo:(id)sender
{    
    FlipsideViewController *controller = [[[FlipsideViewController alloc] initWithNibName:@"FlipsideViewController" bundle:nil] autorelease];
    controller.delegate = self;
    controller.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    [self presentModalViewController:controller animated:YES];
}
-(IBAction)pressGo:(id)sender{
    HistoryViewController *controller = [[[HistoryViewController alloc] initWithNibName:@"HistoryViewController" bundle:nil] autorelease];
    controller.delegate = self;
    controller.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    [self presentModalViewController:controller animated:YES];
}
- (void) loadURLString: (NSString*)address{
	//make sure it has a http:// before it
	if( [address hasPrefix:@"http://"] == FALSE){
		address = [@"http://" stringByAppendingString:address];
	}
    NSURL* url = [NSURL URLWithString:address];
	NSURLRequest * request = [NSURLRequest requestWithURL:url];
	[webView loadRequest: request];
	
	//make the webview the focus
	[webView becomeFirstResponder];

}

-(IBAction)url1:(id)sender{
    urlTextField.text = url1;
    currtab = 1;
}
-(IBAction)url2:(id)sender{
    urlTextField.text = url2;
    currtab = 2;
}
-(IBAction)url3:(id)sender{
    urlTextField.text = url3;
    currtab = 3;
}
-(IBAction)url4:(id)sender{
    urlTextField.text = url4;
    currtab = 4;
}
-(IBAction)url5:(id)sender{
    urlTextField.text = url5;
    currtab = 5;
}
-(IBAction)url6:(id)sender{
    urlTextField.text = url6;
    currtab = 6;
}
-(IBAction)url7:(id)sender{
    urlTextField.text = url7;
    currtab = 7;
}
-(IBAction)url8:(id)sender{
    urlTextField.text = url8;
    currtab = 8;
}
-(IBAction)url9:(id)sender{
    urlTextField.text = url9;
    currtab = 9;
}
- (void)webViewDidStartLoad:(UIWebView *)webView{
    loading.hidden = false;
    reload.hidden = true;
    [loading startAnimating];
    myUrl = webViewX.request.URL;
    nowpage = [myUrl absoluteString];
    urlTextField.text = nowpage;
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    loading.hidden = true;
    [loading stopAnimating];
    reload.hidden = false;
    myUrl = webViewX.request.URL;
    nowpage = [myUrl absoluteString];
    urlTextField.text = nowpage;
    
    [history addObject:nowpage];
    
    [[NSUserDefaults standardUserDefaults] setValue:history forKey:@"history"];
    if (currtab == 1){
        url1 = nowpage;
        [[NSUserDefaults standardUserDefaults] setValue:url1 forKey:@"url1"];
    }
else if (currtab == 2){
    url2 = nowpage;
    [[NSUserDefaults standardUserDefaults] setValue:url2 forKey:@"url2"];
}
else if (currtab == 3){
    url3 = nowpage;
    [[NSUserDefaults standardUserDefaults] setValue:url3 forKey:@"url3"];
}
else if (currtab == 4){
    url4 = nowpage;
    [[NSUserDefaults standardUserDefaults] setValue:url4 forKey:@"url4"];
}
else if (currtab == 5){
    url5 = nowpage;
    [[NSUserDefaults standardUserDefaults] setValue:url5 forKey:@"url5"];
}
else if (currtab == 6){
    url6 = nowpage;
    [[NSUserDefaults standardUserDefaults] setValue:url6 forKey:@"url6"];
}
else if (currtab == 7){
    url7 = nowpage;
    [[NSUserDefaults standardUserDefaults] setValue:url7 forKey:@"url7"];
}
else if (currtab == 8){
    url8 = nowpage;
    [[NSUserDefaults standardUserDefaults] setValue:url8 forKey:@"url8"];
}
else if (currtab == 9){
    url9 = nowpage;
    [[NSUserDefaults standardUserDefaults] setValue:url9 forKey:@"url9"];
}
}
-(IBAction)newfav:(id)sender{
    
    NSLog(@"favorite added");
    
    myUrl = webViewX.request.URL;
    nowpage = [myUrl absoluteString];
    urlTextField.text = nowpage;
    
    NSLog(nowpage);
    
    [favorites addObject:nowpage];
    
    NSLog(@"%@", favorites);
    
    [[NSUserDefaults standardUserDefaults] setValue:favorites forKey:@"favorites"];
}
-(IBAction)zoomaction:(id)sender{
    
}
@end
