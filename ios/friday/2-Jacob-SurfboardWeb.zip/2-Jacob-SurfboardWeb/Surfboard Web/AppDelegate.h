//
//  AppDelegate.h
//  Surfboard Web
//
//  Created by iD Student on 7/10/12.
//  Copyright (c) 2012 Microchip Apps. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MainViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MainViewController *mainViewController;

@end
