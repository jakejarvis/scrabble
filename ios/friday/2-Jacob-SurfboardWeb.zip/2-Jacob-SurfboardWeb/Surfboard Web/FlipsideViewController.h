//
//  FlipsideViewController.h
//  Surfboard Web
//
//  Created by iD Student on 7/10/12.
//  Copyright (c) 2012 Microchip Apps. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FlipsideViewController;

@protocol FlipsideViewControllerDelegate
- (void)flipsideViewControllerDidFinish:(FlipsideViewController *)controller;
@end

@interface FlipsideViewController : UIViewController{
    IBOutlet UILabel *Pagenumber;
    IBOutlet UISegmentedControl *Pagesel;
    IBOutlet UISlider *Pagestep2;
    @public int pages;
    IBOutlet UIButton *Pagecustom;
    IBOutlet UITextField *Pagecustom2;
    IBOutlet UITextField *thenewhome;
    @public NSString *homepage;
}

@property (assign, nonatomic) id <FlipsideViewControllerDelegate> delegate;

- (IBAction)done:(id)sender;
-(IBAction)pagechange:(id)sender;
-(IBAction)incchange:(id)sender;
-(IBAction)custom:(id)sender;
-(IBAction)newhome:(id)sender;
-(IBAction)cleartabs:(id)sender;
@end
