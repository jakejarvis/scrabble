//
//  HistoryViewController.h
//  Surfboard Web
//
//  Created by iD Student on 7/11/12.
//  Copyright (c) 2012 Microchip Apps. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HistoryViewController;

@protocol HistoryViewControllerDelegate
- (void)flipsideViewControllerDidFinish:(HistoryViewController *)controller;
@end

@interface HistoryViewController : UIViewController <UITableViewDelegate, UITableViewDataSource> {
    IBOutlet UITableView *HistoryTable;
    IBOutlet UITableView *favsTable;
}

@property (assign, nonatomic) id <HistoryViewControllerDelegate> delegate;

-(IBAction)buttonclearhistory:(id)sender;
-(IBAction)buttonclearfavs:(id)sender;
@end
