//
//  ViewController.m
//  PassGen
//
//  Created by iD Student on 7/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
     dictionary = [[NSArray alloc] initWithObjects:@"button", @"carpet" , @"bird", @"disable", @"action", @"photo", @"dictionary", @"color", @"high", @"brain", @"pencil", @"brush", @"door", @"orient", @"rational", @"airport", @"album", @"alphabet", @"banker", @"bosses", nil];
    
	if([[NSUserDefaults standardUserDefaults] objectForKey:@"savesEncoded"] != nil) {
		saves = [[NSMutableArray alloc] initWithArray:[NSKeyedUnarchiver unarchiveObjectWithData: [[NSUserDefaults standardUserDefaults] objectForKey:@"savesEncoded"]]];
	} else {
		saves = [[NSMutableArray alloc] init];
	}
}

-(IBAction)passgenButton:(id)sender {
    numOne = arc4random()%dictionary.count;
    numTwo = arc4random()%dictionary.count;
    numThree = arc4random()%dictionary.count;
    numFour = arc4random()%dictionary.count;
    oneLabel.text = [NSString stringWithFormat:@"%@%@%@%@",[dictionary objectAtIndex:(numOne)],[dictionary objectAtIndex:(numTwo)],[dictionary objectAtIndex:(numThree)],[dictionary objectAtIndex:(numFour)]];
}

-(IBAction)saveButton:(id)sender {
	[saves addObject:[NSString stringWithString:oneLabel.text]];
	
    NSData *myEncodedObject = [NSKeyedArchiver archivedDataWithRootObject:saves];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:myEncodedObject forKey:@"savesEncoded"];
	
	[myTableView reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return [saves count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"history item"];
	if (cell == nil) {
		cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"history item"];
	}
	NSUInteger row = [indexPath row];
	
	cell.textLabel.text = [saves objectAtIndex:row];
	
	return cell;
}

    
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return UIInterfaceOrientationIsPortrait(interfaceOrientation);
}

@end
