//
//  ViewController.h
//  PassGen
//
//  Created by iD Student on 7/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource> {
    IBOutlet UILabel *oneLabel;
	
    IBOutlet UITableView *myTableView;
    
    NSArray *dictionary;
    NSMutableArray *saves;
    
    int numOne;
    int numTwo;
    int numThree;
    int numFour;
}

-(IBAction)passgenButton:(id)sender;
-(IBAction)saveButton:(id)sender;



@end
