//
//  ViewController.m
//  RPSv2
//
//  Created by iD Student on 7/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

-(IBAction)pressrock:(id)sender{
    personlabel.text = @"Rock";
    personimage.image = [UIImage imageNamed:@"hand-rock.png"];
    computermove = arc4random()%(3) + 1;
    if(computermove == 1){
        computerlabel.text = @"Rock";
        computerimage.image = [UIImage imageNamed:@"hand-rock.png"];
        finallabel.text = @"TIE!";
    }
    if(computermove == 2){
        computerlabel.text = @"Paper";
        computerimage.image = [UIImage imageNamed:@"hand-paper.png"];
        finallabel.text = @"YOU LOSE";
    }
    if(computermove == 3){
        computerlabel.text = @"Scissors";
        computerimage.image = [UIImage imageNamed:@"hand-scissors.png"];
        finallabel.text = @"YOU WIN!!!!";
    }
    
}

-(IBAction)presspaper:(id)sender{
    personlabel.text = @"Paper";
    personimage.image = [UIImage imageNamed:@"hand-paper.png"];
    computermove = arc4random()%(3) + 1;
    if(computermove == 1){
        computerlabel.text = @"Rock";
        computerimage.image = [UIImage imageNamed:@"hand-rock.png"];
        finallabel.text = @"YOU WIN!!!!";
    }
    if(computermove == 2){
        computerlabel.text = @"Paper";
        computerimage.image = [UIImage imageNamed:@"hand-paper.png"];
        finallabel.text = @"TIE!";
    }
    if(computermove == 3){
        computerlabel.text = @"Scissors";
        computerimage.image = [UIImage imageNamed:@"hand-scissors.png"];
        finallabel.text = @"YOU LOSE";
    }
}

-(IBAction)pressscissors:(id)sender{
    personlabel.text = @"Scissors";
    personimage.image = [UIImage imageNamed:@"hand-scissors.png"];
    computermove = arc4random()%(3) + 1;
    if(computermove == 1){
        computerlabel.text = @"Rock";
        computerimage.image = [UIImage imageNamed:@"hand-rock.png"];
        finallabel.text = @"YOU LOSE";
    }
    if(computermove == 2){
        computerlabel.text = @"Paper";
        computerimage.image = [UIImage imageNamed:@"hand-paper.png"];
        finallabel.text = @"YOU WIN!!!!";
    }
    if(computermove == 3){
        computerlabel.text = @"Scissors";
        computerimage.image = [UIImage imageNamed:@"hand-scissors.png"];
        finallabel.text = @"TIE!";
    }
}

@end
