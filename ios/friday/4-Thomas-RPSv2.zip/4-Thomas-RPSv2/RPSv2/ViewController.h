//
//  ViewController.h
//  RPSv2
//
//  Created by iD Student on 7/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    IBOutlet UILabel *personlabel;
    IBOutlet UILabel *computerlabel;
    IBOutlet UIImageView *personimage;
    IBOutlet UIImageView *computerimage;
    IBOutlet UILabel *finallabel;
    int computermove;
}

-(IBAction)pressrock:(id)sender;

-(IBAction)presspaper:(id)sender;

-(IBAction)pressscissors:(id)sender;

-(void)computerMove;

@end
