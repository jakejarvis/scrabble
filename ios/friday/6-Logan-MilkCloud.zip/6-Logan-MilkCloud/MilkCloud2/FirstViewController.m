//
//  FirstViewController.h
//  MilkCloud
//
//  Created by notanimposter on 7/11/12.
//  Copywrong (c) 2012- 5.5/apple/26 notanimposter Uncorporated. No rights reserved.
//

#import "FirstViewController.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
	if (self) {
		self.title = NSLocalizedString(@"Milk", @"Milk");
		self.tabBarItem.image = [UIImage imageNamed:@"first"];
	}
	return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload {
	[imgMilkLevel release];
	imgMilkLevel = nil;
	[imgMilkLevel release];
	imgMilkLevel = nil;
	[lblStatus release];
	lblStatus = nil;
	[super viewDidUnload];
	// Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	return UIInterfaceOrientationIsPortrait(interfaceOrientation);
}

- (void)dealloc {
	[imgMilkLevel release];
	[imgMilkLevel release];
	[lblStatus release];
	[super dealloc];
}
- (IBAction)btnFetch:(id)sender {
	milkLevel = arc4random()%100 + 1;
	milkLevel = ceil(milkLevel / 20) * 20;
	if (milkLevel >= 10) {
		imgMilkLevel.image = [UIImage imageNamed: [NSString stringWithFormat:@"%d.png", milkLevel]];
		lblStatus.text = @"";
	} else {
		imgMilkLevel.image = [UIImage imageNamed: @"superlow.png"];
		lblStatus.text = @"WARNING: SUPER LOW ON MILK!";
	}
}
@end
