//
//  FirstViewController.h
//  MilkCloud
//
//  Created by notanimposter on 7/11/12.
//  Copywrong (c) 2012- 5.5/apple/26 notanimposter Uncorporated. No rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController {
    IBOutlet UIImageView *imgMilkLevel;
    IBOutlet UILabel *lblStatus;
    int milkLevel;
}
- (IBAction)btnFetch:(id)sender;

@end
