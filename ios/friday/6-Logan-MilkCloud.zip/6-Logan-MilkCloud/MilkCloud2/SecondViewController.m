//
//  SecondViewController.m
//  MilkCloud2
//
//  Created by iD Student on 7/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [lblContainerSize release];
    lblContainerSize = nil;
    [txtUsername release];
    txtUsername = nil;
    [txtPassword release];
    txtPassword = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return UIInterfaceOrientationIsPortrait(interfaceOrientation);
}

- (void)dealloc {
    [lblContainerSize release];
    [txtUsername release];
    [txtPassword release];
    [super dealloc];
}
@end