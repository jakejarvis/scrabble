//
//  SecondViewController.h
//  MilkCloud2
//
//  Created by iD Student on 7/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UITableViewController {
    IBOutlet UISwitch *toggleAutoUpdate;
    IBOutlet UILabel *lblContainerSize;
    IBOutlet UITextField *txtUsername;
    IBOutlet UITextField *txtPassword;
    IBOutlet UITableViewCell *optPint;
    
    IBOutlet UITableViewCell *optQuart;
    IBOutlet UITableViewCell *optHalfGallon;
    IBOutlet UITableViewCell *optGallon;
}

@end
