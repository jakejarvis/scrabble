//
//  Home.m
//  EggPet
//
//  Created by iD Student on 7/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Home.h"
#import <AudioToolbox/AudioToolbox.h>

@interface Home ()

@end

@implementation Home

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    dirtType = [[[NSUserDefaults standardUserDefaults] objectForKey:@"dirtType"] intValue];
    alertOut = 0;
    species = [[[NSUserDefaults standardUserDefaults] objectForKey:@"speciesType"] intValue];     
    eatType = [[[NSUserDefaults standardUserDefaults] objectForKey:@"eatTypeStore"] intValue]; 
    mbf = [[[NSUserDefaults standardUserDefaults] objectForKey:@"mbfType"] intValue];
    statCount = 15;
    statCountClean = 35;
    hunger = (eatType * 5) + 2;
    [[NSUserDefaults standardUserDefaults] setInteger:hunger forKey:@"hungerLevel"]; 
    cleanliness = dirtType + 2;
    [self setCostumes];
    [super viewDidLoad];
    myTimer = [NSTimer scheduledTimerWithTimeInterval:1
											   target:self
											 selector:@selector(updateStats)
											 userInfo:nil
											  repeats:YES];		// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

-(void) setCostumes
{
    NSLog(@"hi");
    if (mbf == 1) {
    if (species == 1)
        {
            imageView.image =[UIImage imageNamed:@"Baby4.png"];
        } else if (species == 2)
        {
        imageView.image =[UIImage imageNamed:@"Baby3.png"];
    } 
    } else if (mbf == 2)
    {
        if (species == 1)
        {
            imageView.image =[UIImage imageNamed:@"Baby2.png"];
        } else if (species == 2)
        {
            imageView.image =[UIImage imageNamed:@"Baby1.png"];
        }
    }
    else if (mbf == 3)
    {
        if (species == 1)
        {
            imageView.image =[UIImage imageNamed:@"Baby5.png"];
        } else if (species == 2)
        {
            imageView.image =[UIImage imageNamed:@"Baby6.png"];
        }
    }
}

-(IBAction) alert
{
    alertOut = 1;
}

-(void) updateStats
{
    mood = cleanliness - dirtType;
    if (mood > -1)
    {
        moodDisplay.image =[UIImage imageNamed:@"Emote1.png"];
    } else if (mood > -4)
    {
        moodDisplay.image =[UIImage imageNamed:@"Emote2.png"];
    } else 
    {
        moodDisplay.image = [UIImage imageNamed:@"Emote3.png"];
    }
    if (alertOut == 0)
    {
    if (hunger >= ((eatType -1) * 5) -2)
{
    if (statCount <= 0) 
    {
        if (hunger > (((eatType - 1) * 5) - 2))
            {
            hunger = hunger - 1;
            cleanliness = cleanliness - (arc4random() % 3);
            [[NSUserDefaults standardUserDefaults] setInteger:hunger forKey:@"hungerLevel"];
            [[NSUserDefaults standardUserDefaults] setInteger:cleanliness forKey:@"cleanLevel"]; 
            statCount = (arc4random() % 40);
            }
        if (hunger == (eatType * 5) - 1)
        {
            alertOut = 1;
            UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Uh-oh!"
                                                             message:@"Your pet is very hungry!  Please feed it."
                                                            delegate:self
                                                   cancelButtonTitle:nil
                                                   otherButtonTitles:@"Okay", nil];
            [alert show]; 
            }
        if (hunger == (eatType - 1) * 5)
        {
            alertOut = 1;
            UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Uh-oh!"
                                                             message:@"Your pet is near death...  Please feed it!"
                                                            delegate:self 
                                                   cancelButtonTitle:nil
                                                   otherButtonTitles:@"Okay", nil];
            [alert show];
        }
        
        if (hunger == ((eatType - 1) * 5) - 2)
        {
            //AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
            alertOut = 1;
            hunger --;
            [[NSUserDefaults standardUserDefaults] setInteger:hunger forKey:@"hungerLevel"];             imageView.image =[UIImage imageNamed:@"Tombstone.png"];
            UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Aww..."
                                                             message:@"Your pet died.  Next time, you should feed it!"
                                                            delegate:self 
                                                   cancelButtonTitle:nil
                                                   otherButtonTitles:@"Okay", nil];
            [alert show];
        }
    } else {
        statCount = statCount - (arc4random() % 3);
    }
}
    }
    
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex   
{
    if (buttonIndex == 0) 
    {
        alertOut = 0;
    }
}
    
-(IBAction) feed : (id) sender
{   if (hunger > (((eatType - 1) * 5) - 2))
{
    hunger ++;
    [[NSUserDefaults standardUserDefaults] setInteger:hunger forKey:@"hungerLevel"]; 
    if (hunger > (eatType + 1) * 5)
        {
            UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Oops!"
                                                             message:@"Don't overfeed your pet!  That is dangerous for its health!"
                                                            delegate:self 
                                                   cancelButtonTitle:nil
                                                   otherButtonTitles:@"Okay", nil];
            [alert show];        }
}
}
-(IBAction) clean : (id) sender
{
    cleanliness ++;
    [[NSUserDefaults standardUserDefaults] setInteger:cleanliness forKey:@"cleanlinessLevel"]; 
    if (cleanliness > 14)
    {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Hey!"
                                                         message:@"Your room is clean enough as is!"
                                                        delegate:self 
                                               cancelButtonTitle:nil
                                               otherButtonTitles:@"Okay", nil];
        [alert show];        
    }

}

-(IBAction) store : (id) sender
{
    
}

-(void)setSpecies:(int)newSpecies {
    species = newSpecies;
}


@end
