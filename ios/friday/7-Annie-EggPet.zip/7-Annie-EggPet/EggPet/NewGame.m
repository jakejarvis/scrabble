//
//  NewGame.m
//  EggPet
//
//  Created by iD Student on 7/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "NewGame.h"
#import "Home.h"

@interface NewGame ()

@end

@implementation NewGame

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	[myTextField setDelegate:self];
    species = (arc4random() % 2) + 1;
    mbf = 2;
    eatType = (arc4random() % 3) + 1;
    dirtType = (arc4random() % 7) + 4;
	// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    
	Home *next = (Home *)segue.destinationViewController;  // access the next view with a variable called next
    [[NSUserDefaults standardUserDefaults] setInteger:mbf forKey:@"mbfType"];
    [[NSUserDefaults standardUserDefaults] setInteger:species forKey:@"speciesType"];
    [[NSUserDefaults standardUserDefaults] setInteger:dirtType forKey:@"dirtType"];
    [[NSUserDefaults standardUserDefaults] setInteger:eatType forKey:@"eatTypeStore"];  
}


-(IBAction) pinkEgg : (id) sender
{
    CGRect tempFrame = arrow.frame;
    tempFrame.origin.x = 110* [[UIScreen mainScreen] scale];
    [arrow setFrame:tempFrame];
    mbf = 2;
}
-(IBAction) blueEgg : (id) sender
{
    CGRect tempFrame = arrow.frame;
    tempFrame.origin.x = 190* [[UIScreen mainScreen] scale];
    [arrow setFrame:tempFrame];
    mbf = 3;
}
-(IBAction) purpleEgg : (id) sender
{
    CGRect tempFrame = arrow.frame;
    tempFrame.origin.x = 150* [[UIScreen mainScreen] scale];
    [arrow setFrame:tempFrame];
    mbf = 1;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	
	[myTextField resignFirstResponder];
	
	return YES;
	
}
@end
