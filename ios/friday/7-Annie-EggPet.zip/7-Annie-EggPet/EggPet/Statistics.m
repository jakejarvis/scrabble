//
//  Statistics.m
//  EggPet
//
//  Created by iD Student on 7/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Statistics.h"

@interface Statistics ()

@end

@implementation Statistics

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    dirtType = [[[NSUserDefaults standardUserDefaults] objectForKey:@"dirtType"] intValue];
    eatType = [[[NSUserDefaults standardUserDefaults] objectForKey:@"eatTypeStore"] intValue];
    hunger = [[[NSUserDefaults standardUserDefaults] objectForKey:@"hungerLevel"] intValue];
    cleanliness = [[[NSUserDefaults standardUserDefaults] objectForKey:@"cleanLevel"] intValue];
  
    [self setTextBoxes];
    [super viewDidLoad];
	
    // Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

-(void) setTextBoxes
{ 
    NSLog([NSString stringWithFormat:@"%i", hunger]);    
    dirtPreferredText.text = [NSString stringWithFormat:@"%i", dirtType];
    
    if (dirtType > 8)
    {
        dirtPersonality.text = @"Super sloppy";
    } else if (dirtType > 5)
    {
        dirtPersonality.text = @"Not neat";
    } else if (dirtType > 3)
    {
        dirtPersonality.text = @"Prefers clean";
    } else {
        dirtPersonality.text = @"Neat freak";
    }

    
    if (eatType == 1) 
    {
        hungerType.text = @"Picky";
    } else if (eatType == 2)
    {
        hungerType.text = @"Moderate";
    } else if (eatType == 3)
    {
        hungerType.text = @"Eager";
    } 
    if (hunger >= 0)
    {
        hungerStat.text = [NSString stringWithFormat:@"%i", hunger];
    } else {
        hungerStat.text = [NSString stringWithFormat:@"%i", 0];
    }
    cleanlinessText.text = [NSString stringWithFormat:@"%i", cleanliness];    
}

-(IBAction) back : (id) sender
{
    [self dismissModalViewControllerAnimated:YES];
}

@end
