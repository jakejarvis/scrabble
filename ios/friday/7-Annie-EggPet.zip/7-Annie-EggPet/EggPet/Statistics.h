//
//  Statistics.h
//  EggPet
//
//  Created by iD Student on 7/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Statistics : UIViewController
{
    int eatType;
    int hunger;
    int dirtType;
    int cleanliness;
    IBOutlet UILabel *hungerType;
    IBOutlet UILabel *hungerStat;
    IBOutlet UILabel *dirtPreferredText;
    IBOutlet UILabel *dirtPersonality;
    IBOutlet UILabel *cleanlinessText;
}

-(IBAction) back : (id) sender;

@end
