//
//  NewGame.h
//  EggPet
//
//  Created by iD Student on 7/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NewGame : UIViewController <UITextFieldDelegate>
{
    int species;
    int mbf;
    int eatType;
    int dirtType;
    IBOutlet UIImageView * arrow;
	IBOutlet UITextField *myTextField;
}

-(IBAction) pinkEgg : (id) sender;
-(IBAction) blueEgg : (id) sender;
-(IBAction) purpleEgg : (id) sender;

@end
