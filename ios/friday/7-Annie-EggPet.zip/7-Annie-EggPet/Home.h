//
//  Home.h
//  EggPet
//
//  Created by iD Student on 7/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Home : UIViewController
{
    NSTimer *myTimer;
    int hunger;
    int cleanliness;
    int statCount;
    int statCountClean;
    int species;
    int mbf;
    int alertOut;
    int eatType;
    int dirtType;
    int mood;
    IBOutlet UIImageView * imageView;
    IBOutlet UIImageView * moodDisplay;
}

-(IBAction) store : (id) sender;
-(IBAction) feed : (id) sender;
-(IBAction) clean : (id) sender;

-(void)setSpecies:(int)newSpecies;

@end
