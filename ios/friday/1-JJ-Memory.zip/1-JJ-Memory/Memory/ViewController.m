//
//  ViewController.m
//  Memory
//
//  Created by iD Student on 7/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    pictures = [[NSMutableArray alloc]init];
    
   
	// "randomly" assign each box to a picture (two boxes to one picture)
    [pictures addObject: [NSNumber numberWithInt: 0]];
    [pictures addObject: [NSNumber numberWithInt: 3]];
    [pictures addObject: [NSNumber numberWithInt: 1]];
    [pictures addObject: [NSNumber numberWithInt: 2]];
    [pictures addObject: [NSNumber numberWithInt: 4]];
    [pictures addObject: [NSNumber numberWithInt: 6]];
    [pictures addObject: [NSNumber numberWithInt: 5]];
    [pictures addObject: [NSNumber numberWithInt: 7]];
    [pictures addObject: [NSNumber numberWithInt: 4]];
    [pictures addObject: [NSNumber numberWithInt: 5]];
    [pictures addObject: [NSNumber numberWithInt: 2]];
    [pictures addObject: [NSNumber numberWithInt: 7]];
    [pictures addObject: [NSNumber numberWithInt: 1]];
    [pictures addObject: [NSNumber numberWithInt: 0]];
    [pictures addObject: [NSNumber numberWithInt: 6]];
    [pictures addObject: [NSNumber numberWithInt: 3]];
    
      
    
    firstTag = -1;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction) pressButton: (id)sender
{
    UIButton *temp = sender;
    
	[temp setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%i.png", [[pictures objectAtIndex:temp.tag] intValue]]] forState:UIControlStateNormal];

	
    //first move
    if (firstTag == -1)
    {
		
		feedback.text = @"";
        firstTag = temp.tag;
		
    }
    //second move
    else if ([pictures objectAtIndex:firstTag] == [pictures objectAtIndex:temp.tag])//got right
    {
		
		feedback.text = @"Right!";
        firstTag = -1;
		
    }
    else if ([pictures objectAtIndex:firstTag] != [pictures objectAtIndex:temp.tag])//got wrong
    {
		
		feedback.text = @"Wrong :(";
		
		// reset the pics after one seconds
		[self performSelector:@selector(flip:) withObject:[NSNumber numberWithInteger:temp.tag] afterDelay:1.0];
		
	
    }
}

- (void)flip:(NSNumber *)card2tag {
	
	UIButton *card1 =  [self.view viewWithTag:firstTag];
	UIButton *card2 =  [self.view viewWithTag:[card2tag intValue]];
	
    [card1 setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];
    [card2 setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];
	
	
	firstTag = -1;
	
}

//reset button
- (IBAction)pressReset:(id)sender
{
    [btn1a setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];
    [btn1b setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];
    [btn1c setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];
    [btn1d setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];

    [btn2a setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];
    [btn2b setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];
    [btn2c setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];
    [btn2d setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];

    [btn3a setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];
    [btn3b setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];
    [btn3c setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];
    [btn3d setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];

    [btn4a setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];
    [btn4b setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];
    [btn4c setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];
    [btn4d setImage:[UIImage imageNamed:@"pkmlogo.png"] forState:UIControlStateNormal];

    firstTag = -1;
}


@end
