//
//  ViewController.h
//  Memory
//
//  Created by iD Student on 7/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
	IBOutlet UILabel *feedback;
	
    IBOutlet UIButton *btn1a;
    IBOutlet UIButton *btn1b;
    IBOutlet UIButton *btn1c;
    IBOutlet UIButton *btn1d;
    
    IBOutlet UIButton *btn2a;
    IBOutlet UIButton *btn2b;
    IBOutlet UIButton *btn2c;
    IBOutlet UIButton *btn2d;
    
    IBOutlet UIButton *btn3a;
    IBOutlet UIButton *btn3b;
    IBOutlet UIButton *btn3c;
    IBOutlet UIButton *btn3d;
    
    IBOutlet UIButton *btn4a;
    IBOutlet UIButton *btn4b;
    IBOutlet UIButton *btn4c;
    IBOutlet UIButton *btn4d;
    
    NSMutableArray *pictures;
	
	NSTimer *flipTimer;
    
    int firstTag;
}

- (IBAction) pressButton: (id)sender;
- (IBAction)pressReset:(id)sender;
- (void)flip:(NSNumber *)card2tag;
@end
