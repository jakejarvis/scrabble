//
//  ViewController.h
//  Hangman1.1
//
//  Created by iD Student on 7/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    NSMutableArray *letters;
    int length;
    NSMutableArray *guesses;
    IBOutlet UITextField *TextBox1;
    IBOutlet UILabel *Label1;
    IBOutlet UILabel *Label2;
    IBOutlet UIImageView *PictureBox1;
    NSString *guessword;
    int wrongs;
    int checkWin;
    BOOL checkWrongs;
}
- (IBAction)Setup:(id)sender;



- (IBAction)LettersIn:(id)sender;



@end
