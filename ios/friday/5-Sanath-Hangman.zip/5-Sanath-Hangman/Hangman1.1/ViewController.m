//
//  ViewController.m
//  Hangman1.1
//
//  Created by iD Student on 7/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    guesses = [[NSMutableArray alloc]init];
    for(int i=0; i<letters.count; i++){
        //[guesses characterAtIndex:(i)]= @"_";
        [guesses addObject:@"_"];
    }
    Label1.text = @"";
    for(int i = 0; i < letters.count; i++) {
        Label1.text = [ NSString stringWithFormat:@"%@%@  ", Label1.text, [guesses objectAtIndex:i]];
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}


- (IBAction)Setup:(id)sender {
    
    if(TextBox1.text.length>12){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"WARNING!"
                                                        message:@"You have a limit of 12 letters(only alphabets!)"
                                                       delegate:self 
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles: nil];
        [alert show];
        
    }
    else{
        letters = [[NSMutableArray alloc]init];
        guessword = TextBox1.text;

        for(int i = 0; i < TextBox1.text.length; i++) {
            [letters addObject:[guessword substringWithRange:NSMakeRange(i, 1)]];
        }
    }
}

- (IBAction)LettersIn:(id)sender {
    checkWrongs = YES;
    UIButton *current = sender;
    NSString *curlet;
    NSString *temp;
    NSString *temp2;
    for(int i = 0; i < letters.count; i++) {
        NSString *name;
        name = [letters objectAtIndex:i];
        curlet = current.titleLabel.text;
        temp = [curlet uppercaseString];
        temp2 = [curlet lowercaseString];
        if([name isEqualToString:temp] || [name isEqualToString:temp2]){
            [guesses replaceObjectAtIndex:i withObject:curlet];
            checkWrongs = NO;
        }
    }
    if(checkWrongs == YES){
        wrongs = wrongs + 1;
    }
    current.imageView.image = [UIImage imageNamed:@"LetterGone.png"];
    current.enabled = NO; 
    //current.titleLabel.textColor = [UIColor redColor];
    [self UpdateLabel];
    [self ChangePic];
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    ViewController *next=(ViewController*)segue.destinationViewController;
  
	if(letters != nil) {
		next -> letters = [letters copy];
	}
	
	if(guessword != nil) {
		next -> guessword = [guessword copy];
	}
               
}

- (void) UpdateLabel{
    Label1.text = @"";
    for(int i = 0; i < letters.count; i++) {
        Label1.text = [ NSString stringWithFormat:@"%@%@  ", Label1.text, [guesses objectAtIndex:i]];
    }                   
}
               
- (void) ChangePic{
	
    NSString *picname;
    picname = [ NSString stringWithFormat:@"Hangman%i.png", wrongs];
    UIImage *image = [UIImage imageNamed: picname];
    [PictureBox1 setImage:image];
	
    if(wrongs == 6){
        Label2.text = @"YOU LOSE!!";
        Label2.textColor = [UIColor whiteColor];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"The word was..."
                                                        message:guessword
                                                       delegate:self 
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles: nil];
        [alert show];
        //show that the word was not guessed
    }
    else if( [guesses containsObject:@"_"] == NO ) {
        Label2.text = @"YOU WIN!!";
        Label2.textColor = [UIColor whiteColor];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"GREAT JOB!"
                                                        message:@"YOU GUESSED THE WORD!"
                                                       delegate:self 
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles: nil];
        [alert show];
    }
}
@end