//
//  ViewController.m
//  AlertTest
//
//  Created by Jake Jarvis on 6/28/12.
//  Copyright (c) 2012 Jake Jarvis. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Congrats!"
													message:@"You were totally rad!"
												   delegate:self 
										  cancelButtonTitle:nil
										  otherButtonTitles:@"Play again!", @"Main menu", @"Annie's mayonaise", nil];
	
	[alert show];
}



- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	NSLog([NSString stringWithFormat:@"%i", buttonIndex]);
	
	
	if(buttonIndex == 0) {
		
		
		
		
		
	} else if(buttonIndex == 1) {
		
		
		// main menu
		
		[self dismissModalViewControllerAnimated:YES];

		
	} else if(buttonIndex == 2) {
			
		
		// play again
		
		
		//[self presentModalViewController:controller animated:YES];
		
		[self presentModalViewController:[self.storyboard instantiateViewControllerWithIdentifier:@"snake"] animated:NO];
		
		
	}
}





- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
