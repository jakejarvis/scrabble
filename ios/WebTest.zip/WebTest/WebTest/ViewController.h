//
//  ViewController.h
//  WebTest
//
//  Created by Jake Jarvis on 7/4/12.
//  Copyright (c) 2012 Jake Jarvis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
	IBOutlet UIWebView *webView;
	IBOutlet UITextField *urlTextField;
}

// We define our own method to load a web address
// using a string to make it simpler
- (void) loadURLString: (NSString*)address;

@end
