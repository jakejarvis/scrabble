//
//  ViewController.m
//  WebTest
//
//  Created by Jake Jarvis on 7/4/12.
//  Copyright (c) 2012 Jake Jarvis. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	
	
	//load home page
	[self loadURLString:@"http://scrabblerocks.com"];
}

- (BOOL)textFieldShouldReturn:(UITextField *)inTextField {
	[self loadURLString: [inTextField text]];
	return YES;
}

//  This will do a google search instead
//  [self loadURLString: [@"http://google.com/search?q=" stringByAppendingString:[sender text]]];

- (void) loadURLString: (NSString*)address{  
	//make sure it has a http:// before it  
	if( [address hasPrefix:@"http://"] == FALSE){
		address = [@"http://" stringByAppendingString:address];
	}
	
	NSLog(@"Loading webpage %@", address );
	
	//load it into the UIWebView
	NSURL* url = [NSURL URLWithString:address];
	NSURLRequest * request = [NSURLRequest requestWithURL:url];
	[webView loadRequest: request];
	
	//make the webview the focus
	[webView becomeFirstResponder];
}

// when the URL changes we want to change the address at the top
// this is known as a delegate method, where another class will always
// call a certain method on your code

// this one gets called every time a page finished loading
- (void)webViewDidFinishLoad:(UIWebView *) delagateWebView {
	urlTextField.text = [delagateWebView.request.mainDocumentURL absoluteString];
}




- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
