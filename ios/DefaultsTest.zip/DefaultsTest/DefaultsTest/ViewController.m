//
//  ViewController.m
//  DefaultsTest
//
//  Created by Jake Jarvis on 7/5/12.
//  Copyright (c) 2012 Jake Jarvis. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (IBAction)pressSave:(id)sender {
	
	
	[[NSUserDefaults standardUserDefaults] setValue:password1.text forKey:@"password1"];
	[[NSUserDefaults standardUserDefaults] setValue:password2.text forKey:@"password2"];
	[[NSUserDefaults standardUserDefaults] setValue:password3.text forKey:@"password3"];
	
	
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	
	
	password1.text = [[NSUserDefaults standardUserDefaults] stringForKey:@"password1"];
	password2.text = [[NSUserDefaults standardUserDefaults] stringForKey:@"password2"];
	password3.text = [[NSUserDefaults standardUserDefaults] stringForKey:@"password3"];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
