//
//  ViewController.h
//  DefaultsTest
//
//  Created by Jake Jarvis on 7/5/12.
//  Copyright (c) 2012 Jake Jarvis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITextFieldDelegate> {
	
	IBOutlet UITextField *password1;
	IBOutlet UITextField *password2;
	IBOutlet UITextField *password3;
	
}


- (IBAction)pressSave:(id)sender;

@end
